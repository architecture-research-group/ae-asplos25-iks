import numpy as np
import random

# Function to generate Gaussian distributed clusters for vector b
def generate_gaussian_clusters(num_clusters, total_vectors, vector_length, cluster_means=None, cluster_stds=None):
    """
    Generates vectors grouped into clusters with Gaussian distribution.
    
    Args:
        num_clusters (int): Number of clusters to generate.
        total_vectors (int): Total number of vectors to generate.
        vector_length (int): Dimension of each vector.
        cluster_means (list of lists): List of means for each cluster. Each element should be a list of length `vector_length`.
        cluster_stds (list of lists): List of standard deviations for each cluster. Each element should be a list of length `vector_length`.
    
    Returns:
        tuple: A tuple containing:
               - A list of Gaussian distributed vectors.
               - The cluster means used for each cluster.
               - The standard deviations used for each cluster.
    """
    if cluster_means is None:
        cluster_means = [np.random.uniform(-5, 5, vector_length) for _ in range(num_clusters)]
    if cluster_stds is None:
        cluster_stds = [10 for _ in range(num_clusters)]
    
    # Allocate the number of vectors per cluster randomly but ensure they sum up to `total_vectors`
    cluster_sizes = np.random.multinomial(total_vectors, [1/num_clusters]*num_clusters)
    
    vectors = []
    for i in range(num_clusters):
        # Generate vectors for each cluster with specified mean and std
        cluster_vectors = np.random.normal(loc=cluster_means[i], scale=cluster_stds[i], size=(cluster_sizes[i], vector_length)).astype(np.float16)
        vectors.extend(cluster_vectors)
    
    return vectors, cluster_means, cluster_stds

# Function to generate random vectors in fp16
def generate_random_vectors(length, mean, std_dev):
    # Generate a vector with Gaussian distribution similar to a cluster's mean and std deviation
    vector = np.random.normal(loc=mean, scale=std_dev, size=length).astype(np.float16)
    return vector

# Function to generate 16-bit IDs
def generate_16bit_ids(num_vectors):
    ids = []
    for i in range(1, num_vectors + 1):
        id_bin = bin(i)[2:].zfill(16)
        ids.append(id_bin)
    return ids

# Function to perform fp16 dot product with cumulative sums and output to files
def fp16_dp_golden(vector_a, group_b, group_ids, j, dot_products):
    golden_list = ""
    golden_list_dec = ""
    cumulative_sum = np.zeros(len(group_b), dtype=np.float16)  # Initialize cumulative sums for each group with fp16

    reset_signal = 1
    feed_bit = 0
    if j == 0:
        for k in range(3):
            if k == 1:
                reset_signal = 0
            else:
                reset_signal = 1
            line_bin = f"{'0'*16}_"  # Start the line with vector_a binary
            line_dec = f"{0}(fp16)_"  # Start the line with vector_a decimal
            for idx in range(len(group_b)):
                # Append each group_b element and cumulative sum to the line
                line_bin += f"{'0'*16}_{'0'*16}_{'0'*16}_"
                line_dec += f"{0}(fp16) * {0}(fp16)_{0}_"
            golden_list += (line_bin + f"{feed_bit}_{reset_signal}\n")
            golden_list_dec += (line_dec + f"{feed_bit}_{reset_signal}\n")

    reset_signal = 1
    feed_bit = 1

    # Main loop over vector_a
    for i in range(len(vector_a)):
        a_bin = bin(np.float16(vector_a[i]).view("H"))[2:].zfill(16)
        line_bin = f"{a_bin}_"
        line_dec = f"{vector_a[i]}(fp16)_"

        for idx in range(len(group_b)):
            if i < 3:
                cumulative_sum[idx] = np.float16(0)
            elif i == 3:
                cumulative_sum[idx] = np.float16(vector_a[0]) * np.float16(group_b[idx][0])
            else:
                cumulative_sum[idx] += np.float16(vector_a[i-3]) * np.float16(group_b[idx][i-3])

            b_bin = bin(np.float16(group_b[idx][i]).view("H"))[2:].zfill(16)
            cum_sum_bin = bin(np.float16(cumulative_sum[idx]).view("H"))[2:].zfill(16)
            id_bin = group_ids[idx]

            line_bin += f"{b_bin}_{cum_sum_bin}_{id_bin}_"
            line_dec += f"{group_b[idx][i]}(fp16) => {cumulative_sum[idx]}(fp16)_{id_bin}_"

        golden_list += (line_bin + f"{feed_bit}_{reset_signal}\n")
        golden_list_dec += (line_dec + f"{feed_bit}_{reset_signal}\n")

    feed_bit = 0

    # Final three cycles to output remaining cumulative sums
    for k in range(3, 0, -1):
        line_bin = f"{'0'*16}_"
        line_dec = "0(fp16)_"

        for idx in range(len(group_b)):
            cumulative_sum[idx] += np.float16(vector_a[-k]) * np.float16(group_b[idx][-k])
            b_bin = bin(np.float16(group_b[idx][-k]).view("H"))[2:].zfill(16)
            cum_sum_bin = bin(np.float16(cumulative_sum[idx]).view("H"))[2:].zfill(16)
            id_bin = group_ids[idx]

            line_bin += f"{b_bin}_{cum_sum_bin}_{id_bin}_"
            line_dec += f"{group_b[idx][-k]}(fp16) * {cumulative_sum[idx]}(fp16)_{id_bin}_"

        golden_list += (line_bin + f"{feed_bit}_{reset_signal}\n")
        golden_list_dec += (line_dec + f"{feed_bit}_{reset_signal}\n")

    with open("dotprod_bin_68_mac_fp16_g.txt", 'a') as f:
        f.write(golden_list)

    with open("dotprod_dec_68_mac_fp16_g.txt", 'a') as f:
        f.write(golden_list_dec)

    for idx in range(len(group_b)):
        dot_products.append((cumulative_sum[idx], group_ids[idx]))


# Parameters
vector_length = 768  # Dimension of each vector
n = 68 * 2  # Number of vectors b
m = 68  # Number of MACs (multiply-accumulate operations) - defines group size
num_clusters = 4  # Number of Gaussian clusters
K = 32  # Limit for top K dot products

# Generate n vectors b from multiple Gaussian clusters
vectors_b, cluster_means, cluster_stds = generate_gaussian_clusters(num_clusters, n, vector_length)

# Choose vector a to be similar to one of the clusters
chosen_cluster_idx = random.randint(0, num_clusters - 1)  # Randomly select one of the clusters
vector_a = generate_random_vectors(vector_length, cluster_means[chosen_cluster_idx], cluster_stds[chosen_cluster_idx])

# Generate unique 16-bit IDs for each vector b
ids_b = generate_16bit_ids(n)

# Group the vectors based on the number of MACs (m)
grouped_vectors_b = [vectors_b[i:i+m] for i in range(0, len(vectors_b), m)]
grouped_ids_b = [ids_b[i:i+m] for i in range(0, len(ids_b), m)]

# Clear the content of the files before appending
open("./dotprod_bin_68_mac_fp16_g.txt", 'w').close()
open("./dotprod_dec_68_mac_fp16_g.txt", 'w').close()

# Store dot products with their IDs for sorting later
dot_products = []

# Loop over the groups and call fp16_dp_golden, passing index j
for j in range(len(grouped_vectors_b)):
    fp16_dp_golden(vector_a, grouped_vectors_b[j], grouped_ids_b[j], j, dot_products)

# Sort dot products in descending order
sorted_dot_products = sorted(dot_products, key=lambda x: x[0], reverse=True)

# Print the first K sorted dot products with their IDs
print(f"\nTop {K} sorted dot products:")
for dot_product, id_bin in sorted_dot_products[:K]:
    print(f"Dot product: {dot_product}, ID: {hex(int(id_bin, 2))[2:].zfill(4)}")
